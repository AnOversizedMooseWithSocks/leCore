"""tests/test_text_undo_memory.py -- /api/text must not deep-copy every stroke path into its undo snapshot.

Measured in the crystal-journal swarm run (2026-09-27): with ~2,700 strokes on other layers, each add_text rebuilt
the stroke shadow (a full private copy of every path) for its snapshot, and the 24 live undo entries each kept a
copy. 38 text calls took 80 s and grew the studio from 1.6 to 4.3 GB; the live studio was OOM-killed at 5.3 GB.
Text is append-only on the stroke list (it records ONE new stroke and edits no path), so the shadow stays valid.
"""
import os

os.environ.setdefault("PYTHONHASHSEED", "0")


def _doc_with_strokes(n=200):
    import lestudio as L
    d = L.Document(400, 300, background=(0.95, 0.92, 0.84))
    d.add_layer(name="paint")
    d.add_layer(name="text")
    paint, text = d.layers[-2].id, d.layers[-1].id
    for k in range(n):                                   # a sketch's worth of strokes on ANOTHER layer
        d.paint(paint, [[10 + k % 300, 20 + (k * 7) % 250, 1.0], [30 + k % 300, 40 + (k * 7) % 250, 1.0],
                        [50 + k % 300, 45 + (k * 7) % 250, 1.0], [70 + k % 300, 50 + (k * 7) % 250, 1.0],
                        [90 + k % 300, 52 + (k * 7) % 250, 1.0], [110 + k % 300, 55 + (k * 7) % 250, 1.0]],
                color=(0.2, 0.2, 0.2), radius=1.5)
    return d, text


def test_text_keeps_the_stroke_shadow_instead_of_rebuilding_it():
    d, text = _doc_with_strokes()
    d._stroke_copies()                                   # the shadow is current
    before = d._stroke_shadow
    for k in range(5):
        d.add_text(text, "note %d" % k, x=10, y=10 + 20 * k, size=14, color=(0.24, 0.18, 0.12))
    assert d._stroke_shadow is before                    # extended in place, never dropped and rebuilt
    assert len(d._stroke_shadow) == len(d.strokes)


def test_text_undo_snapshots_share_the_path_copies():
    d, text = _doc_with_strokes()
    for k in range(6):
        d.add_text(text, "note %d" % k, x=10, y=10 + 20 * k, size=14, color=(0.24, 0.18, 0.12))
    snaps = [e[1] for e in d._undo if e[0] == "Text"]
    assert len(snaps) >= 2
    first, last = snaps[0]["strokes"], snaps[-1]["strokes"]
    # the pre-existing strokes are the SAME shadow entries in every snapshot (one copy, shared by reference)
    assert all(a is b for a, b in zip(first, last))


def test_undoing_text_still_restores_the_document():
    d, text = _doc_with_strokes(n=20)
    n0 = len(d.strokes)
    d.add_text(text, "hello", x=10, y=10, size=14, color=(0.24, 0.18, 0.12))
    assert len(d.strokes) == n0 + 1
    d.undo()
    assert len(d.strokes) == n0
